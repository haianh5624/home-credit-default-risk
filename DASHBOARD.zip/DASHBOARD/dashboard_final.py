import streamlit as st
import pandas as pd
import numpy as np
import joblib
import time
import plotly.express as px
import plotly.graph_objects as go

# --- 1. CẤU HÌNH TRANG ---
st.set_page_config(page_title="Hệ thống chấm điểm tín dụng", page_icon="💳", layout="wide")

# --- 2. LOAD MÔ HÌNH ---
@st.cache_resource
def load_resources():
    xgb = joblib.load('model_xgb.pkl')
    lgbm = joblib.load('model_lgbm.pkl')
    rf = joblib.load('model_rf.pkl')
    feats = joblib.load('feature_names.pkl')
    imputer = joblib.load('imputer_values.pkl')
    return xgb, lgbm, rf, feats, imputer

try:
    with st.spinner("Đang khởi động hệ thống ..."):
        model_xgb, model_lgbm, model_rf, feature_names, imputer_vals = load_resources()
except Exception as e:
    st.error(f"⚠️ Lỗi: Thiếu file model (.pkl). {e}")
    st.stop()

# --- 3. SIDEBAR & UPLOAD ---
with st.sidebar:
    st.title("📂 NHẬP DỮ LIỆU")
    uploaded_file = st.file_uploader("Tải lên file hồ sơ (CSV)", type=['csv'])
    
    # --- LOGIC HIỂN THỊ THÔNG BÁO ---
    if uploaded_file is None:
        # Trường hợp 1: Chưa upload -> Hiện hướng dẫn (Ảnh 2)
        st.info("💡 Upload file đã xử lý (file_demo_chuan.csv) để chạy.")
    else:
        # Trường hợp 2: Đã upload -> Đọc file để đếm dòng -> Hiện kết quả (Ảnh 1)
        # (Đọc tạm để đếm dòng)
        try:
            df_temp = pd.read_csv(uploaded_file)
            st.success(f"✅ Đã tải: {len(df_temp)} hồ sơ.")
            
            # QUAN TRỌNG: Reset con trỏ file về đầu để code bên dưới đọc lại được
            uploaded_file.seek(0)
        except Exception as e:
            st.error("File lỗi không đọc được!")

# --- 4. XỬ LÝ & DỰ BÁO ---
if uploaded_file is not None:
    # A. Đọc file (Lần đọc chính thức)
    df_input = pd.read_csv(uploaded_file)
    
    # B. Kiểm tra cột ID
    if 'SK_ID_CURR' not in df_input.columns:
        st.error("❌ File thiếu cột 'SK_ID_CURR'!")
        st.stop()

    # C. Nút chạy (Chỉ hiện khi chưa có kết quả)
    if 'df_result' not in st.session_state:
        if st.button("🚀 BẮT ĐẦU CHẤM ĐIỂM", type="primary"):
            progress_bar = st.progress(0)
            status = st.empty()
            
            # 1. Chuẩn bị
            status.text("Đang xử lý dữ liệu...")
            ids = df_input['SK_ID_CURR']
            X = df_input.reindex(columns=feature_names, fill_value=0)
            progress_bar.progress(20)
            
            # 2. Chạy Model
            status.text("Đang chạy ENSEMBLE MODEL...")
            p1 = model_xgb.predict_proba(X)[:, 1]
            p2 = model_lgbm.predict_proba(X)[:, 1]
            X_rf = X.fillna(imputer_vals)
            p3 = model_rf.predict_proba(X_rf)[:, 1]
            progress_bar.progress(80)
            
            # 3. Ensemble
            status.text("Đang tổng hợp kết quả...")
            final_score = (0.4 * p1) + (0.4 * p2) + (0.2 * p3)
            
            df_res = pd.DataFrame({
                'SK_ID_CURR': ids,
                'RISK_SCORE': final_score,
                'XGB': p1, 'LGBM': p2, 'RF': p3
            })
            
            def classify(x):
                if x < 0.05: return "An toàn"
                if x < 0.647: return "Cần xem xét"
                return "Nguy hiểm"
            
            df_res['Phân loại'] = df_res['RISK_SCORE'].apply(classify)
            
            st.session_state['df_result'] = df_res
            progress_bar.progress(100)
            time.sleep(0.5)
            status.empty()
            progress_bar.empty()
            st.rerun() # Tải lại để hiện Dashboard

    # --- 5. HIỂN THỊ DASHBOARD (KHI ĐÃ CÓ KẾT QUẢ) ---
    if 'df_result' in st.session_state:
        df_full = st.session_state['df_result']
        
        # --- A. BỘ LỌC (SLICER) ---
        with st.sidebar:
            st.markdown("---")
            st.header("🎛️ BỘ LỌC KẾT QUẢ")
            
            # Slicer 1: Chọn nhóm
            risk_filter = st.multiselect(
                "Chọn Nhóm rủi ro:",
                ["An toàn", "Cần xem xét", "Nguy hiểm"],
                default=["An toàn", "Cần xem xét", "Nguy hiểm"]
            )
            
            # Slicer 2: Khoảng điểm
            score_range = st.slider(
                "Lọc theo Điểm rủi ro:",
                min_value=0.0, max_value=1.0, value=(0.0, 1.0)
            )
            
            # Nút Reset
            if st.button("🔄 Reset Dữ liệu"):
                del st.session_state['df_result']
                st.rerun()

        # --- ÁP DỤNG BỘ LỌC ---
        df_view = df_full[
            (df_full['Phân loại'].isin(risk_filter)) &
            (df_full['RISK_SCORE'] >= score_range[0]) &
            (df_full['RISK_SCORE'] <= score_range[1])
        ]

        # --- B. TIÊU ĐỀ & KPI ---
        st.title("📊 KẾT QUẢ THẨM ĐỊNH")
        st.caption(f"Đang hiển thị: {len(df_view)} / {len(df_full)} hồ sơ")
        st.markdown("---")
        
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("📂 Tổng hồ sơ lọc", len(df_view))
        c2.metric("⛔ Nguy hiểm (Từ chối)", (df_view['Phân loại']=='Nguy hiểm').sum())
        c3.metric("✅ An toàn (Duyệt tự động)", (df_view['Phân loại']=='An toàn').sum())
        c4.metric("📉 Rủi ro TB", f"{df_view['RISK_SCORE'].mean():.2%}")
        
        # --- C. TABS BIỂU ĐỒ ---
        t1, t2, t3 = st.tabs(["📈 Tổng quan ", "🔍 Tra cứu & Danh sách", "🤖 Phân tích Mô hình"])
        
        # TAB 1: BIỂU ĐỒ TỔNG QUAN 
        with t1:
            col1, col2 = st.columns(2)
            
            # Định nghĩa màu sắc chuẩn
            color_map = {'An toàn':'#2ecc71', 'Cần xem xét':'#f1c40f', 'Nguy hiểm':'#e74c3c'}
            
            with col1:
                st.subheader("1. Cơ cấu Rủi ro (Donut)")
                fig_pie = px.pie(df_view, names='Phân loại', values='RISK_SCORE', 
                                 color='Phân loại', color_discrete_map=color_map, hole=0.4)
                st.plotly_chart(fig_pie, use_container_width=True)
                
            with col2:
                st.subheader("2. Số lượng theo Nhóm (Bar Chart)")
                # Tính toán số lượng
                counts = df_view['Phân loại'].value_counts().reset_index()
                counts.columns = ['Loại', 'Số lượng']
                fig_bar = px.bar(counts, x='Loại', y='Số lượng', color='Loại', 
                                 color_discrete_map=color_map, text_auto=True)
                st.plotly_chart(fig_bar, use_container_width=True)
            
            st.subheader("3. Phổ điểm Rủi ro (Histogram)")
            fig_hist = px.histogram(df_view, x="RISK_SCORE", nbins=50, color="Phân loại",
                                    color_discrete_map=color_map, marginal="box")
            st.plotly_chart(fig_hist, use_container_width=True)

        # TAB 2: TRA CỨU
        with t2:
            c_s, c_i = st.columns([1, 2])
            with c_s:
                st.subheader("Tra cứu ID")
                # Lấy danh sách ID từ df_view (đã lọc)
                search_id = st.selectbox("Chọn Mã KH:", df_view['SK_ID_CURR'].head(500)) # Giới hạn 500 để load nhanh
                
                if search_id:
                    rec = df_full[df_full['SK_ID_CURR'] == search_id].iloc[0]
                    
                    # Đồng hồ đo
                    fig_g = go.Figure(go.Indicator(
                        mode = "gauge+number", value = rec['RISK_SCORE']*100,
                        title = {'text': "Điểm Rủi ro (%)"},
                        gauge = {'axis': {'range': [0, 100]}, 'bar': {'color': "darkblue"},
                                 'steps': [{'range': [0, 5], 'color': "#2ecc71"}, 
                                           {'range': [5, 64.7], 'color': "#f1c40f"}, 
                                           {'range': [64.7, 100], 'color': "#e74c3c"}]}
                    ))
                    fig_g.update_layout(height=250, margin=dict(l=20,r=20,t=0,b=0))
                    st.plotly_chart(fig_g, use_container_width=True)
                    
                    # Kết luận
                    lbl = rec['Phân loại']
                    if lbl == 'Nguy hiểm': st.error(f"⛔ {lbl}")
                    elif lbl == 'An toàn': st.success(f"✅ {lbl}")
                    else: st.warning(f"⚠️ {lbl}")

            with c_i:
                st.subheader("Danh sách hồ sơ")
                # Bảng trơn, không style để tránh lỗi
                st.dataframe(df_view[['SK_ID_CURR', 'RISK_SCORE', 'Phân loại', 'XGB', 'LGBM', 'RF']].head(1000), 
                             use_container_width=True, height=400)
                
                csv = df_view.to_csv(index=False).encode('utf-8')
                st.download_button("📥 Tải danh sách lọc", csv, "ket_qua.csv", "text/csv")

        # TAB 3: PHÂN TÍCH MÔ HÌNH (Đã thay 3D bằng Heatmap)
        with t3:
            c3, c4 = st.columns(2)
            
            with c3:
                st.subheader("4. Tương quan Mô hình (Heatmap)")
                st.caption("Thể hiện độ giống nhau giữa các mô hình thành phần.")
                # Tính ma trận tương quan
                corr = df_view[['XGB', 'LGBM', 'RF', 'RISK_SCORE']].corr()
                fig_heat = px.imshow(corr, text_auto=True, color_continuous_scale='Blues')
                st.plotly_chart(fig_heat, use_container_width=True)
                
            with c4:
                st.subheader("5. Độ phân tán điểm số (Box Plot)")
                st.caption("So sánh khoảng điểm dự báo của từng mô hình.")
                df_melt = df_view.head(1000).melt(
                    value_vars=['XGB', 'LGBM', 'RF'], 
                    var_name='Model', value_name='Score'
                )
                fig_box = px.box(df_melt, x='Model', y='Score', color='Model', points="all")
                st.plotly_chart(fig_box, use_container_width=True)

else:
    st.info(" Chào bạn! Hãy upload file để chấm điểm tín dụng.")